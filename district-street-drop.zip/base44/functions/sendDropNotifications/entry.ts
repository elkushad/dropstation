import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  const now = new Date().toISOString();

  // 1. Publish draft products whose drop_date has passed
  //    Get all active drops that have started
  const allDrops = await base44.asServiceRole.entities.Drop.filter({});
  const liveDropIds = new Set(
    allDrops.filter(d => d.drop_date <= now).map(d => d.id)
  );

  let publishedProducts = 0;
  if (liveDropIds.size > 0) {
    // Get draft products with drop_id that are now live
    const draftProducts = await base44.asServiceRole.entities.Product.filter({ status: 'draft' });
    const toPublish = draftProducts.filter(p => p.drop_id && liveDropIds.has(p.drop_id));

    for (const product of toPublish) {
      await base44.asServiceRole.entities.Product.update(product.id, { status: 'active' });
      publishedProducts++;
    }
  }

  // 2. Send email notifications to subscribed users
  const allNotifications = await base44.asServiceRole.entities.DropNotification.filter({ notified: false });
  const due = allNotifications.filter(n => n.drop_date && n.drop_date <= now);

  let sent = 0;
  // Batch updates to reduce API calls
  const updatePromises = [];
  
  for (const notif of due) {
    const dropDate = new Date(notif.drop_date);
    const timeStr = dropDate.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' });
    const dateStr = dropDate.toLocaleDateString('es', { weekday: 'long', day: 'numeric', month: 'long' });

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: notif.user_email,
      subject: `🔔 Drop en vivo: ${notif.drop_title} de ${notif.brand_name}`,
      body: `
        <div style="font-family: sans-serif; background: #09090b; color: #fafafa; padding: 32px; max-width: 520px; margin: auto; border-radius: 16px;">
          <h1 style="font-size: 24px; font-weight: 900; color: #a78bfa; margin: 0 0 8px;">¡El drop ya está aquí! 🚀</h1>
          <h2 style="font-size: 20px; font-weight: 800; margin: 0 0 4px;">${notif.drop_title}</h2>
          <p style="color: #a1a1aa; margin: 0 0 24px;">por <strong style="color: #fafafa;">${notif.brand_name}</strong> · ${dateStr} a las ${timeStr}</p>
          <a href="${Deno.env.get('BASE44_APP_URL') || 'https://preview-sandbox--69b71676ad1bc6cf572c1b06.base44.app'}/BrandProfile?id=${notif.brand_id || ''}"
             style="display: inline-block; background: #7c3aed; color: white; padding: 14px 28px; border-radius: 999px; font-weight: 700; text-decoration: none; font-size: 15px;">
            Ver drop ahora →
          </a>
          <p style="color: #52525b; font-size: 12px; margin-top: 32px;">Recibiste este email porque activaste la notificación para este drop en DropStation.</p>
        </div>
      `,
    });

    updatePromises.push(
      base44.asServiceRole.entities.DropNotification.update(notif.id, { notified: true })
    );
    sent++;
  }
  
  // Wait for all updates to complete
  if (updatePromises.length > 0) {
    await Promise.all(updatePromises);
  }

  return Response.json({ publishedProducts, emailsSent: sent });
});